package com.example.mentalwellbeing

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.google.firebase.auth.FirebaseAuth


class LoginFragment : Fragment() {

    private lateinit var reset: TextView
    private lateinit var register: TextView
    private lateinit var login: Button
    private lateinit var email: EditText
    private lateinit var password: EditText

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_login, container, false)
        reset = view.findViewById(R.id.resettxt)
        register = view.findViewById(R.id.registertxt)
        login = view.findViewById(R.id.loginbtn)
        email = view.findViewById(R.id.email)
        password = view.findViewById(R.id.password)

        reset.setOnClickListener{
            findNavController().navigate(R.id.action_loginFragment_to_resetPasswordFragment)
        }

        register.setOnClickListener{
            findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }


        return view
    }

}
package com.example.mentalwellbeing

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText


class RegisterFragment : Fragment() {

    private lateinit var emaill : EditText
    private lateinit var password : EditText
    private lateinit var registerbtn : Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_register, container, false)

        emaill = view.findViewById(R.id.emaill)
        password = view.findViewById(R.id.passwordd)
        registerbtn = view.findViewById(R.id.registerbtn)
        

        return view


    }

}